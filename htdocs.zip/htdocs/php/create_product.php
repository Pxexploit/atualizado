<?php
$servername = "localhost"; 
$username = "root";
$password = ""; 
$dbname = "sistema_login"; 


$conn = new mysqli($servername, $username, $password, $dbname);


if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    $nome_produto = $_POST['nome_produto'];
    $nome_produto = $_POST['nome_produto'];
    $preco = $_POST['preco'];
    
    // Infos dos vendedores
    $email_vendedor = $_POST['email_vendedor'];
    $nome_loja = $_POST['nome_loja'];
    $nome_vendedor = $_POST['nome_vendedor'];


    $imagem_produto = $_FILES['imagem_produto']['name'];
    $target_dir = "uploads/"; // pasta aonde todas img vai ser salva
    $target_file = $target_dir . basename($imagem_produto);


    if (move_uploaded_file($_FILES['imagem_produto']['tmp_name'], $target_file)) {
        // Inserir dados no banco de dados
        $sql = "INSERT INTO produtos (nome_produto, nome_produto, preco, imagem_produto, email_vendedor, nome_loja, nome_vendedor) 
                VALUES ('$nome_produto', '$nome_produto', '$preco', '$imagem_produto', '$email_vendedor', '$nome_loja', '$nome_vendedor')";

        if ($conn->query($sql) === TRUE) {
            // cod para a página de produtos
            header('Location: telaprodutos.php');
            exit; 
        } else {
            echo "Erro ao cadastrar produto: " . $conn->error;
        }
    } else {
        echo "Erro ao enviar a imagem.";
    }
}

$conn->close();
?>
