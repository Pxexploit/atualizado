<?php
session_start();

// Verificação de acesso apenas para vendedores
if (!isset($_SESSION['usuario_email']) || $_SESSION['usuario_tipo'] !== 'vendedor') {
    echo "Você precisa estar logado como vendedor para acessar esta página.";
    exit();
}

$mensagem = "";

// Conexão com o banco
$conn = new mysqli("localhost", "root", "", "sistema_login");
if ($conn->connect_error) {
    die("Falha na conexão: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $nome_produto = $_POST['nome_produto'];
    $descricao = $_POST['descricao'];
    $preco = $_POST['preco'];

    // Upload da imagem
    $imagem_nome = $_FILES['imagem_produto']['name'];
    $imagem_tmp = $_FILES['imagem_produto']['tmp_name'];
    $imagem_destino = "uploads/" . basename($imagem_nome);

    // Cria pasta se não existir
    if (!is_dir("uploads")) {
        mkdir("uploads", 0777, true);
    }

    if (move_uploaded_file($imagem_tmp, $imagem_destino)) {
        // Obter ID do vendedor
        $stmt = $conn->prepare("SELECT id FROM usuarios WHERE email = ? AND tipo_usuario = 'vendedor'");
        $stmt->bind_param("s", $_SESSION['usuario_email']);
        $stmt->execute();
        $resultado = $stmt->get_result();

        if ($resultado->num_rows > 0) {
            $vendedor = $resultado->fetch_assoc();
            $id_vendedor = $vendedor['id'];

            // Obter loja associada ao vendedor
            $stmt_loja = $conn->prepare("SELECT id_loja FROM vendedor WHERE id_vendedor = ?");
            $stmt_loja->bind_param("i", $id_vendedor);
            $stmt_loja->execute();
            $res_loja = $stmt_loja->get_result();

            if ($res_loja->num_rows > 0) {
                $loja = $res_loja->fetch_assoc();
                $id_loja = $loja['id_loja'];

                // Inserir produto
                $stmt_produto = $conn->prepare("INSERT INTO produto (nome, preco, descricao, id_loja) VALUES (?, ?, ?, ?)");
                $stmt_produto->bind_param("sdsi", $nome_produto, $preco, $descricao, $id_loja);

                if ($stmt_produto->execute()) {
                    $mensagem = "Produto cadastrado com sucesso!";
                } else {
                    $mensagem = "Erro ao cadastrar produto: " . $conn->error;
                }
            } else {
                $mensagem = "Você precisa cadastrar uma loja antes de adicionar produtos.";
            }
        } else {
            $mensagem = "Vendedor não encontrado.";
        }
    } else {
        $mensagem = "Erro ao fazer upload da imagem.";
    }

    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastrar Produto</title>
    <link rel="stylesheet" href="css/cdstroprod.css"> 
</head>
<body>
    <div class="container">
        <h2>Cadastrar Produto</h2>

        <?php if (!empty($mensagem)): ?>
            <div class="mensagem"><?php echo $mensagem; ?></div>
        <?php endif; ?>

        <form action="" method="POST" enctype="multipart/form-data">
            <label for="nome_produto">Nome do Produto:</label>
            <input type="text" id="nome_produto" name="nome_produto" required>

            <label for="descricao">Descrição:</label>
            <textarea id="descricao" name="descricao" required></textarea>

            <label for="preco">Preço:</label>
            <input type="number" id="preco" name="preco" step="0.01" required>

            <label for="imagem_produto">Imagem:</label>
            <input type="file" id="imagem_produto" name="imagem_produto" accept="image/*" required>

            <button type="submit">Cadastrar Produto</button>
        </form>
    </div>
</body>
</html>
