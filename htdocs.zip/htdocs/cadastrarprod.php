<?php
session_start();

// Verificação de acesso apenas para vendedores
if (!isset($_SESSION['usuario_email']) || $_SESSION['usuario_tipo'] !== 'vendedor') {
    echo "Você precisa estar logado como vendedor para acessar esta página.";
    exit();
}

$mensagem = "";
$tipo_mensagem = ""; // 'sucesso' ou 'erro'

// Conexão com o banco
$conn = new mysqli("localhost", "root", "", "sistema_login");
if ($conn->connect_error) {
    die("Falha na conexão: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $nome_produto = htmlspecialchars(trim($_POST['nome_produto']));
    $descricao = htmlspecialchars(trim($_POST['descricao']));
    $preco = floatval($_POST['preco']);

    // Upload da imagem
    $imagem_nome = $_FILES['imagem_produto']['name'];
    $imagem_tmp = $_FILES['imagem_produto']['tmp_name'];
    $imagem_destino = "uploads/" . basename($imagem_nome);

    // Cria pasta se não existir
    if (!is_dir("uploads")) {
        mkdir("uploads", 0777, true);
    }

    if (move_uploaded_file($imagem_tmp, $imagem_destino)) {
        // Buscar vendedor e loja
        $stmt = $conn->prepare("SELECT id_vendedor, id_loja FROM vendedor WHERE email = ?");
        $stmt->bind_param("s", $_SESSION['usuario_email']);
        $stmt->execute();
        $resultado = $stmt->get_result();

        if ($resultado->num_rows > 0) {
            $vendedor = $resultado->fetch_assoc();
            $id_loja = $vendedor['id_loja'];
            $stmt->close();

            if ($id_loja) {
                // Inserir produto com imagem
                $stmt_produto = $conn->prepare("INSERT INTO produto (nome, preco, descricao, imagem, id_loja) VALUES (?, ?, ?, ?, ?)");
                $stmt_produto->bind_param("sdssi", $nome_produto, $preco, $descricao, $imagem_nome, $id_loja);

                if ($stmt_produto->execute()) {
                    $mensagem = "Produto cadastrado com sucesso!";
                    $tipo_mensagem = "sucesso";
                } else {
                    $mensagem = "Erro ao cadastrar produto: " . $conn->error;
                    $tipo_mensagem = "erro";
                }
                $stmt_produto->close();
            } else {
                $mensagem = "Você precisa estar associado a uma loja para cadastrar produtos.";
                $tipo_mensagem = "erro";
            }
        } else {
            $mensagem = "Vendedor não encontrado.";
            $tipo_mensagem = "erro";
        }
    } else {
        $mensagem = "Erro ao fazer upload da imagem.";
        $tipo_mensagem = "erro";
    }

    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastrar Produto</title>
    <link rel="stylesheet" href="css/cdstroprod.css"> 
</head>
<body>
    <div class="container">
        <h2>Cadastrar Produto</h2>

        <?php if (!empty($mensagem)): ?>
            <div id="mensagemdeubom" class="<?php echo $tipo_mensagem; ?>">
                <?php echo $mensagem; ?>
            </div>
        <?php endif; ?>

        <form action="" method="POST" enctype="multipart/form-data">
            <label for="nome_produto">Nome do Produto:</label>
            <input type="text" id="nome_produto" name="nome_produto" required>

            <label for="descricao">Descrição:</label>
            <textarea id="descricao" name="descricao" required></textarea>

            <label for="preco">Preço:</label>
            <input type="number" id="preco" name="preco" step="0.01" required>

            <label for="imagem_produto">Imagem:</label>
            <input type="file" id="imagem_produto" name="imagem_produto" accept="image/*" required>

            <button type="submit">Cadastrar Produto</button>
            <button onclick="window.location.href='MenuVendedor.php'">Voltar ao Menu</button>
        </form>
    </div>
</body>
</html>
