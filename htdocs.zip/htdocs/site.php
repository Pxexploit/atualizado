
<?php
    session_start();

    if( $_SESSION['usuario_email'] = "email" && $_SESSION['usuario_senha'] = "senha"){


if (!isset($_SESSION['usuario_email']) || !isset($_SESSION['usuario_tipo'])) {
   
    header("Location: login.php");
    exit();
}


if ($_SESSION['usuario_tipo'] == 'vendedor') {
    
    echo "Bem-vindo vendedor!";
} else {

    echo "Bem-vindo cliente!";
}
?>


<!DOCTYPE html><html lang="pt-br"><head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Marketplace Taquaritinga-SP</title>
    
    

    <link href="css/imports_new.css" rel="stylesheet">

    <link href="css/aos.css" rel="stylesheet">

    <link rel="stylesheet" href="css/all.css">

    <script src="js/jquery.min.js"></script>

    < src="js/aos.js"></script>

    <link href="css/remixicon.css" rel="stylesheet">
    <link rel="shortcut icon" type="image/x-icon" href="images/site2.png">

    <meta name="robots" content="index">
    <meta name="theme-color" content="#2596be">
    <meta property="og:site_name" content="E commerce">
    <meta property="og:type" content="article">
    <meta property="og:image" content="images/site2.png">
    <meta property="og:description" content="O E commerce de taquaritinga é a melhor opção!">
    
</head>

<body data-aos-easing="ease" data-aos-duration="400" data-aos-delay="0">

    <header id="navbar">
        <div class="container">

            <nav class="navbar navbar-expand-xl navbar-dark">
                <a class="navbar-brand" href="#"><img src="images/site2.png" alt="" style="width: 4.7rem;"></a>
                <button class="navbar-toggler collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
                    <ul class="navbar-nav">
                        <li class="nav-item active">
                            <a class="nav-link px-md-2 px-0" href="#home" onclick="change_nav(1)">Home<span class="sr-only">(current)</span></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link px-md-2 px-0" href="#about" onclick="change_nav(2)">Produtos</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link px-md-2 px-0" href="#pricing" onclick="change_nav(3)">Ofertas</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link px-md-2 px-0" href="#faqs" onclick="change_nav(5)">FAQ</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link px-md-2 px-0" href="#contacts" onclick="change_nav(6)">Contato</a>
                        </li>
                    </ul>
                    <div class="d-lg-flex d-block">
                       
                            <a href="logout.php" class="button nav-btn d-flex justify-content-center align-items-center mt-md-0 mt-2 mb-md-0 mb-2 ml-4">Logout</a>
                            
                        </div>
                        <div id="logoutButton" style="display: none;">
 <!-- ainda esta em teste--> <!-- <a  href="logout.php" class="button nav-btn d-flex justify-content-center align-items-center mt-md-0 mt-2 mb-md-0 mb-2 ml-4">Sair</a>-->
                        </div>
                </div>
            </nav>
        </div>

    </header>

    <//script>

        function checkLoginStatus() {
            
            var loggedIn = false; 

          
            if (loggedIn) {
                document.getElementById("authButtons").style.display = "none"; 
                document.getElementById("logoutButton").style.display = "block"; 
            } else {
                document.getElementById("authButtons").style.display = "block"; 
                document.getElementById("logoutButton").style.display = "none"; 
            }
        }
        window.onload = checkLoginStatus;
    </script>


    <section style="overflow: hidden;" id="landing">
        <div class="container h-100">
            <div class="row h-100 justify-content-center align-items-center text-center">
                <div class="col-12">
                    <div class="content">
                        <span style="font-size: 1.3rem; position:relative; bottom:0.1rem"></span>
                        <span class="span-off"></span><span class="typed-cursor" aria-hidden="true">|</span>
                        <h1>Com <span style="color: var(--primary)">Nosso site</span><br> é mais facil vender<span style="color: var(--primary)"> Em nossa cidade.</span></h1>
                        <p>Está procurando um produto?<br>
                            Conheça nossa plataforma! </p>
                        <a href="produtos.php" onclick="change_nav(3)" class="button rounded-circle">Comprar pelo Site</a>
                        <a href="#0" onclick="change_nav(2)" class="button read">Saiba Mais</a>
                    </div>
        </div>
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 180">
            <path fill="#121415" fill-opacity="1" d="M0,128L120,138.7C240,149,480,171,720,170.7C960,171,1200,149,1320,138.7L1440,128L1440,320L1320,320C1200,320,960,320,720,320C480,320,240,320,120,320L0,320Z" data-darkreader-inline-fill="" style="--darkreader-inline-fill:#007acc;"></path>
        </svg>
    </div></div></section>


    <!-- N APAGAR ESSA PARTE -->
    
    <section id="purchase-faq">
        <div class="container">
            <div class="row text-center justify-content-center mb-4">
                <div class="col-11">
                    <div class="top-text"> 
                      

            <div class="row text-center justify-content-center faq">
                <div class="col-12">
                    <div class="top-text">
                        <h2 data-aos="fade-up" data-aos-duration="1000" class="aos-init">Perguntas Frequentes (FAQ)</h2>
                        <p data-aos="fade-up" data-aos-duration="1000" class="aos-init">Algumas perguntas basicas sobre nós.</p>
                    </div>
                </div>
            </div>
            <div class="row justify-content-center">
                <div class="col-10">
                    <div class="accordion" id="accordionPanelsStayOpen">
                        <div class="accordion-item aos-init" data-aos="fade-up" data-aos-duration="1500">
                            <h2 class="accordion-header" id="panelsStayOpen-headingOne">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapseOne" aria-expanded="false" aria-controls="panelsStayOpen-collapseOne">
                                    Quem nós somos?
                                </button>
                            </h2>
                            <div id="panelsStayOpen-collapseOne" class="accordion-collapse collapse" aria-labelledby="panelsStayOpen-headingOne">
                                <div class="accordion-body">
                                    Somos um serviço online de vendas local para a cidade de taquaritinga.
                                </div>
                            </div>
                        </div>
                        <div class="accordion-item aos-init" data-aos="fade-up" data-aos-duration="2000">
                            <h2 class="accordion-header" id="panelsStayOpen-headingThree">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapseThree" aria-expanded="false" aria-controls="panelsStayOpen-collapseThree">
                                    Vocês oferecem trocas e devoluções?
                                </button>
                            </h2>
                            <div id="panelsStayOpen-collapseThree" class="accordion-collapse collapse" aria-labelledby="panelsStayOpen-headingThree">
                                <div class="accordion-body">
                                    Sim, garantimos a troca ou devolução do produto em até 7 dias corridos após o recebimento, caso o item esteja em perfeito estado e na embalagem original. Para iniciar o processo de devolução, entre em contato com nossa equipe de atendimento ao cliente.
                                </div>
                            </div>
                        </div>
                        <div class="accordion-item aos-init" data-aos="fade-up" data-aos-duration="2500">
                            <h2 class="accordion-header" id="panelsStayOpen-headingFour">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapseFour" aria-expanded="false" aria-controls="panelsStayOpen-collapseFour">
                                    Como faço para entrar em contato com o atendimento?
                                </button>
                            </h2>
                            <div id="panelsStayOpen-collapseFour" class="accordion-collapse collapse" aria-labelledby="panelsStayOpen-headingFour">
                                <div class="accordion-body">
                                    Caso precise de ajuda ou tenha dúvidas, entre em contato conosco através dos seguintes canais:

                                    WhatsApp: (16) 9XXXX-XXXX
                                    E-mail: atendimento@ecommerce-taquaritinga.com.br
                                    Telefone: (16) 3456-XXXX Estamos disponíveis de segunda a sexta-feira, das 8h às 18h.
                            </div>                            
                        
                            </div>
                        </div>
                    </div> 
                     
            </div></div></div></div></div></div></section>

    <section id="contact">
        <div class="container">
            <div class="row text-center">
                <div class="col-12">
                    <h2 data-aos="fade" data-aos-duration="600" class="aos-init">Procurando por nós?</h2>
                    <p data-aos="fade" data-aos-duration="600" class="aos-init">Aqui esta o melhor meio de nos comunicarmos.</p>
                    <a data-aos="fade" data-aos-duration="600" href=" coloque aq
                    " class="button rounded-circle px-5 aos-init">Instagram</a>
                </div>
            </div>
        </div>
    </section>


    <footer>
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <div class="items d-flex">
                        <div>
                            <h5 style="color:#ffffff;">marketplace</h5>
                        </div>
                    </div>
                </div>
                <div class="col-md-8 text-right">
                    <div class="items d-flex justify-content-md-end justify-content-start">
                        <ul>
                            <li><a onclick="change_nav(1)" href="#home">Inicio</a></li>
                            <li><a onclick="change_nav(2)" href="#about">Produtos</a></li>
                            <li><a onclick="change_nav(4)" href="#faqs">FAQ</a></li>
                            <li><a onclick="change_nav(5)" href="#contacts">Contato</a></li>
                        </ul>
                        <ul>
                            <li><a href="https://discord.gg/JPmnzxqSXZ">Terms of service</a></li>
                            <li><a href="https://discord.gg/JPmnzxqSXZ">Features</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <p class="text-center">Copyright 2025-2026 Loja online. Todos os direitos reservados.</p>
    </footer>

    <script src="js/bootstrap.js"></script>
    <script src="typed.js%25402.0.12"></script>

    <script>
        AOS.init({
            disable: 'mobile',
            once: true,
        });
    </script>
    <script>
        var typed = new Typed('.span-off', {
            strings: [ 'Seja bem-vindo(a) Ao nosso site', ],
            loop: true,
            typeSpeed: 60,
            backSpeed: 30,
        });
    </script><style type="text/css" data-typed-js-css="true">
        .typed-cursor{
          opacity: 1;
        }
        .typed-cursor.typed-cursor--blink{
          animation: typedjsBlink 0.7s infinite;
          -webkit-animation: typedjsBlink 0.7s infinite;
                  animation: typedjsBlink 0.7s infinite;
        }
        @keyframes typedjsBlink{
          50% { opacity: 0.0; }
        }
        @-webkit-keyframes typedjsBlink{
          0% { opacity: 1; }
          50% { opacity: 0.0; }
          100% { opacity: 1; }
        }
      </style>
    <script>
        function remove_hash() {
            setTimeout(() => {
                history.replaceState({}, document.title, ".");
            }, 5);
        }

        var scroll = $(window).scrollTop();
        if (scroll > 70) {
            $("#navbar").addClass("active");
        } else {
            $("#navbar").removeClass("active");
        }

        function change_nav(tab) {
            remove_hash();
            if (tab == 1) {
                $(window).scrollTop(0);
            } else if (tab == 2) {
                $(window).scrollTop($("#why-choose").offset().top - 200);
            } else if (tab == 3) {
                $(window).scrollTop($("#purchase-faq").offset().top - 100);
            } else if (tab == 4) {
                $(window).scrollTop($("#purchase-faq .faq").offset().top - 1000);
            } else if (tab == 5) {
                $(window).scrollTop($("#purchase-faq .faq").offset().top - 300);
            } else if (tab == 6) {
                $(window).scrollTop($("body").height());
            }
        }

        $(window).scroll(function () {
            var scroll = $(window).scrollTop();
            if (scroll > 70) {
                $("#navbar").addClass("active");
            } else {
                $("#navbar").removeClass("active");
            }
        });
    </script>

</section></body></html>
    
    <?php
         }else{
        echo "Nao logado";
     }
     ?>