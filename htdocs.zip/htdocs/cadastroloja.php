<?php
session_start();

// Verifica se o usuário está logado e se é vendedor
if (
    isset($_SESSION['usuario_email']) &&
    isset($_SESSION['usuario_senha']) &&
    isset($_SESSION['usuario_tipo']) &&
    $_SESSION['usuario_tipo'] == 'vendedor'
) {

    // Verifica se o vendedor está tentando cadastrar a loja
    if (isset($_POST['cadastrar_loja'])) {
        $nome_loja = $_POST['nome_loja'];
        $descricao = $_POST['descricao'];

        // Conexão com o banco de dados
        $conn = new mysqli("localhost", "root", "", "sistema_login");

        if ($conn->connect_error) {
            die("Conexão falhou: " . $conn->connect_error);
        }

        // Verificar se o id_vendedor existe na tabela vendedor
        $id_vendedor = $_SESSION['usuario_id'];  // Supondo que isso está na sessão

        // Verificar se o vendedor existe
        $sql_check_vendedor = "SELECT id_vendedor FROM vendedor WHERE id_vendedor = '$id_vendedor' LIMIT 1";
        $result = $conn->query($sql_check_vendedor);

        if ($result && $result->num_rows > 0) {
            // Cadastrar a loja
            $sql = "INSERT INTO loja (nome, endereco) VALUES ('$nome_loja', '$descricao')";
            if ($conn->query($sql) === TRUE) {
                $id_loja = $conn->insert_id;

                // Atualizar o vendedor com o id_loja criado
                $update_sql = "UPDATE vendedor SET id_loja = '$id_loja' WHERE id_vendedor = '$id_vendedor'";
                if ($conn->query($update_sql) === TRUE) {
                    echo "Loja cadastrada e vinculada ao vendedor com sucesso!";
                } else {
                    echo "Erro ao vincular loja ao vendedor: " . $conn->error;
                }
            } else {
                echo "Erro ao cadastrar loja: " . $conn->error;
            }
        } else {
            echo "Erro: Vendedor não encontrado ou não autorizado.";
        }

        $conn->close();
    }
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastrar Loja</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>

<header>
    <h1>Cadastrar Loja</h1>
    <a href="logout.php">Logout</a>
</header>

<section>
    <form action="cadastroloja.php" method="POST">
        <label for="nome_loja">Nome da Loja:</label>
        <input type="text" id="nome_loja" name="nome_loja" required>
        
        <label for="descricao">Endereço da Loja:</label>
        <textarea id="descricao" name="descricao" required></textarea>
        
        <button type="submit" name="cadastrar_loja">Cadastrar Loja</button>
    </form>
</section>

</body>
</html>
<?php
} else {
    echo "Você precisa estar logado como vendedor para acessar esta página.";
}
?>
