<?php
session_start();

// Verificação de acesso apenas para vendedores
if (!isset($_SESSION['usuario_email']) || $_SESSION['usuario_tipo'] !== 'vendedor') {
    echo "Você precisa estar logado como vendedor para acessar esta página.";
    exit();
}

$mensagem = "";

// Conexão com o banco
$conn = new mysqli("localhost", "root", "", "sistema_login");
if ($conn->connect_error) {
    die("Falha na conexão: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $email_vendedor = $_SESSION['usuario_email'];
    $nome_loja = $_POST['nome_loja'];
    $endereco_loja = $_POST['endereco_loja'];
    $cnpj_cpf_input = preg_replace('/[^0-9]/', '', $_POST['cnpj_cpf_loja']);

    // Determinar se é CNPJ ou CPF
    $cnpj = null;
    $cpf = null;
    if (strlen($cnpj_cpf_input) === 14) {
        $cnpj = $cnpj_cpf_input;
    } elseif (strlen($cnpj_cpf_input) === 11) {
        $cpf = $cnpj_cpf_input;
    } else {
        $mensagem = "CNPJ ou CPF inválido.";
    }

    if (empty($mensagem)) {
        // Inserir loja
        $stmt_loja = $conn->prepare("INSERT INTO loja (nome, endereco, cnpj, cpf) VALUES (?, ?, ?, ?)");
        $stmt_loja->bind_param("ssss", $nome_loja, $endereco_loja, $cnpj, $cpf);

        if ($stmt_loja->execute()) {
            $id_loja = $conn->insert_id;

            // Buscar ID do vendedor pela tabela correta (vendedor)
            $stmt_vend = $conn->prepare("SELECT id_vendedor FROM vendedor WHERE email = ?");
            $stmt_vend->bind_param("s", $email_vendedor);
            $stmt_vend->execute();
            $res_vend = $stmt_vend->get_result();

            if ($res_vend->num_rows > 0) {
                $vendedor = $res_vend->fetch_assoc();
                $id_vendedor = $vendedor['id_vendedor'];

                // Atualiza a loja do vendedor
                $stmt_vinculo = $conn->prepare("UPDATE vendedor SET id_loja = ? WHERE id_vendedor = ?");
                $stmt_vinculo->bind_param("ii", $id_loja, $id_vendedor);

                if ($stmt_vinculo->execute()) {
                    $mensagem = "Loja cadastrada com sucesso e vinculada ao vendedor!";
                } else {
                    $mensagem = "Erro ao vincular loja ao vendedor: " . $stmt_vinculo->error;
                }
            } else {
                $mensagem = "Vendedor não encontrado na tabela.";
            }

            $stmt_vend->close();
        } else {
            $mensagem = "Erro ao cadastrar loja: " . $stmt_loja->error;
        }

        $stmt_loja->close();
    }

    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastrar Loja</title>
    <!-- Aqui está o link para o seu arquivo CSS -->
    <link rel="stylesheet" href="css/cdstrovend.css"> 
</head>
<body>
    <!-- Notificação que será exibida com a mensagem -->
    <?php if (!empty($mensagem)): ?>
        <div id="mensagemdeubom"><?php echo $mensagem; ?></div>
    <?php endif; ?>

    <div class="container">
        <h2>Cadastrar Loja</h2>

        <form action="" method="POST">
            <label for="nome_loja">Nome da Loja:</label>
            <input type="text" id="nome_loja" name="nome_loja" required>

            <label for="endereco_loja">Endereço da Loja:</label>
            <input type="text" id="endereco_loja" name="endereco_loja" required>

            <label for="cnpj_cpf_loja">CNPJ ou CPF da Loja:</label>
            <input type="text" id="cnpj_cpf_loja" name="cnpj_cpf_loja" required>

            <button type="submit">Cadastrar Loja</button>
        </form>
    </div>
</body>
</html>
